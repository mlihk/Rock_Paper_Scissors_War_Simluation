Hey, to use this program, simply double click on the run file!

-Marcus